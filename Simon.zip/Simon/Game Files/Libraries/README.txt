The SIMON source code requires the masm32 library as well as an edited version of the Irvine 32 library.
To install follow these steps:
1.) Install the masm32 using the "masm32 library install" executible
2.) Follow the steps to install masm32.
3.) Once done navigate to "C:\masm32\include" and move the Irvine32_NOWIN.inc file into the folder.
4.) You now have all the files needed to run the source code.
