﻿███████████████████████████████████████████████████████████████████
██                                                               ██
██       ██████                                                  ██
██       ███     ███  ██████ ██████  ██████████  ████   ██       ██
██       ██████  ███  ███ ██ ██ ███  ███    ███  ██ ███ ██       ██
██          ███  ███  ███ █████ ███  ███    ███  ██  ██ ██       ██
██       ██████  ███  ███  ███  ███  ██████████  ██   ████       ██
██                                                               ██
███████████████████████████████████████████████████████████████████
            by John Keys, Christoper Potter, Maya Bloom

                        Welcome to Simon!
        This read me file will help you get playing in no time!

    ┌───────────────────────────────────────────────────────────┐
    │ Project Specifications:                                   │
    ╞═══════════════════════════════════════════════════════════╡
    │ Lines of Code:  1188                                      │
    │                                                           │
    │ Roles:                                                    │
    │ Maya Bloom - Team Leader and Sounds                       │
    │ Christopher Potter - Game and Board Visuals               │
    │ John Keys - User Input and AI                             │
    │                                                           │
    │ Known Bugs:                                               │
    │ 1.If user clicks while the Simon AI is giving signals the │
    │   clicks are still recorded.                              │
    │ 2.If you click where the exit button would while the game │
    │   over animation is playing the game window will close    │
    │   because the mouse click is still recorded and carried   │
    │   out once the game goes back to the start screen.        │
    └───────────────────────────────────────────────────────────┘

    ┌───────────────────────────────────────────────────────────┐
    │ LAUNCHING THE GAME:                                       │
    ╞═══════════════════════════════════════════════════════════╡
    │ To launchg the game simply click on the icon labeled      │
    │ Simon in the Simon folder. Please make sure the           │
    │ computer's power option is NOT set to Power Saving.       │
    │ If the game window's height is smaller than the width     │
    │ please continue to FIRST TIME RUNNING INSTRUCTIONS below. │
    └───────────────────────────────────────────────────────────┘

    ┌───────────────────────────────────────────────────────────┐
    │ FIRST TIME RUNNING INSTRUCTIONS                           │
    ╞═══════════════════════════════════════════════════════════╡
    │ Simon requires a specific window size of 68 width by 36   │
    │ height to optimally run. Upon running Simon for the first │
    │ time please right click along the top window border and   │
    │ select "Properties" from the dropdown menu. Once open     │
    │ please navigate to the "Layout" tab along the top and     │
    │ under "Screen Buffer Size" and "Window Size "please change│
    │ the Width to 68 and the Height to 36 if they are not set. │
    │ Click "Okay" at the bottom to close the Properties menu.  │
    │ Please click the "Exit" box on the screen and relaunch.   │
    └───────────────────────────────────────────────────────────┘

    ┌───────────────────────────────────────────────────────────┐
    │ GAMEPLAY INSTRUCTIONS:                                    │
    ╞═══════════════════════════════════════════════════════════╡
    │ When you click PLAY the game will start. Simon will give  │
    │ you the first signal. You must then press the same signal │
    │ If correct, Simon will repeat the same signal and add one │
    │ more signal after it. You must repeat these signals in    │
    │ order. The game will continue like this until youy press  │
    │ an incorrect signal. If you press an incorrect signal     │
    │ your score will be recorded if it is a new high score     │
    │ and you will be returned to the start screen.             │
    └───────────────────────────────────────────────────────────┘

    ┌───────────────────────────────────────────────────────────┐
    │ GAME FILES:                                               │
    ╞═══════════════════════════════════════════════════════════╡
    │ For the game to run properly please make sure the         │
    │ following files are in the Game Files folder:             │
    │ Simon.exe                                                 │
    │ Simon Icon.ico                                            │
    │ GameOverSound.wav                                         │
    │ SplashScreen.wav                                          │
    │ GreenBeep1.wav                                            │
    │ GreenBeep2.wav                                            │
    │ GreenBeep3.wav                                            │
    │ RedBeep1.wav                                              │
    │ RedBeep2.wav                                              │
    │ RedBeep3.wav                                              │
    │ YellowBeep1.wav                                           │
    │ YellowBeep2.wav                                           │
    │ YellowBeep3.wav                                           │
    └───────────────────────────────────────────────────────────┘
    ┌───────────────────────────────────────────────────────────┐
    │ CITATIONS:                                                │
    ╞═══════════════════════════════════════════════════════════╡
    │ Intro Music:                                              │
    │ Divinity feat. Amy Millian by Porter Robinson             │
    │                                                           │
    │ Game Audio:                                               │
    │ Hasbro Interactive Original Simon Game Audio              │
    └───────────────────────────────────────────────────────────┘